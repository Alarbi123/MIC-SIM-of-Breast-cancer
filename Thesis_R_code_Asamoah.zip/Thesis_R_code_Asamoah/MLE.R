#library(tidyverse)
#library(xtable)
library(dplyr)
#library(MASS)

#Reads the data set
rm(list = ls())
data<-read.csv("C:/Users/Asamoah/OneDrive/Desktop/BMI_tumsize.csv", header = T)
tumsize <- data[,3]
var <- data[,2]



#Define the likelihood function
Ln_exp <- function(w, negative=FALSE){
  if(any(w<=0))
    return(-Inf)
  tau <- w[1]
  tau1 <- tau
  tau2 <- tau
  gammavar <- w[2]
  v_cell<-(0.5^3)*pi/6
  vcd<-(tumsize^3)*pi/6
  if(negative)
    L <- -sum(log(tau1)+tau1*log(tau2)+log(gammavar)+(-(tau1+1))*log(tau2+gammavar*(vcd-v_cell)))
  else
    L <- sum(log(tau1)+tau1*log(tau2)+log(gammavar)+(-(tau1+1))*log(tau2+gammavar*(vcd-v_cell)))
  return(L)
}

# Initial parameters
initial_params <- c(tau = exp(-0.165), gammavar = exp(-9.602)) 
set.seed(123)

# #Optimizes the log likelihood function to obtain parameter estimates
mle_result <- optim(
  par=initial_params, 
  negative=TRUE,
  lower=c(0.09,0.000001), upper=c(2,1),
  fn = Ln_exp, 
  method = "L-BFGS-B" # Nelder-Mead,
  )

#print parameter estimates 
mle_result$par
print(log(mle_result$par))




######Profile Likelihood Confidence Interval:
#par 1
# Get the MLE estimates
set.seed(123456)
mle_params <- mle_result$par

#calculate tandard error (se) from hessian_matrix
library(numDeriv)
set.seed(12345)
hessian_matrix <- hessian(function(p) -Ln_exp(p, negative = TRUE), mle_result$par)
var_cov_matrix <- solve(hessian_matrix)
print(var_cov_matrix)

se <- sqrt(diag(var_cov_matrix))

# Choose the parameter for profiling (adjust index as needed)
param_to_profile <- 1

# Z-score for a 95% confidence interval
z_score <- qnorm(0.95)

# Confidence interval for the parameter
conf_interval <- mle_params[param_to_profile] + c(-1, 1) * z_score * se[param_to_profile]

#par 2

# Choose the parameter for profiling (adjust index as needed)
param_to_profile_2 <- 2


# Z-score for a 95% confidence interval
z_score <- qnorm(0.95)

# Confidence interval for the parameter
conf_interval_2 <- mle_params[param_to_profile_2] + c(-1, 1) * z_score * se[param_to_profile_2]

# Print the results
results_df <- data.frame(
  estimate = mle_result$par,
  std_error = c(se[param_to_profile],se[param_to_profile_2]),
  CIs.1 = c(conf_interval[1],conf_interval_2[1]),
  CIs.2 = c(conf_interval[2],conf_interval_2[2])
)
print(results_df)

#log transform
results_df <- data.frame(
  estimate = log(mle_result$par),
  std_error = c(se[param_to_profile],se[param_to_profile_2]),
  CIs.1 = log(c(conf_interval[1],conf_interval_2[1])),
  CIs.2 = log(c(conf_interval[2],conf_interval_2[2]))
)

print(results_df)



#output log transform
#parameter     estimate    std_error      CIs.1      CIs.2
#tau      8.162318e-01 2.005881e-02 7.832380e-01 8.492256e-01
#gammavar 6.481139e-05 9.560799e-06 4.908528e-05 8.053751e-05



########
# Store log-likelihoods and perform Likelihood Ratio Test
lrt_results <- matrix(0, nrow = length(mle_result$par), ncol = 3)

for (i in seq_along(mle_result$par)) {
  # Create a copy of the MLE parameters
  mle_copy <- mle_result$par
  
  # Define the likelihood function for the null model (parameter fixed)
  Ln_exp_null <- function(w) {
    if (any(w <= 0)) return(-Inf)
    mle_copy[i] <- w
    Ln_exp(mle_copy, negative = TRUE)
  }
  
  # Log-likelihood for the full model
  log_likelihood_full <- Ln_exp(mle_result$par, negative = TRUE)
  
  # Log-likelihood for the nested model (with parameter fixed)
  tryCatch({
    log_likelihood_nested <- -optimize(Ln_exp_null, c(0.000001, 2), tol = 1e-6)$objective
  }, error = function(e) {
    cat("Warning: Optimization failed for the nested model with parameter ", names(mle_result$par)[i], "\n")
    log_likelihood_nested <- -Inf  # Set to -Inf in case of failure
  })
  
  # Likelihood ratio test statistic
  lrt_stat <- 2 * (log_likelihood_full - log_likelihood_nested)
  
  # Degrees of freedom for chi-squared distribution
  df_chi2 <- 1
  
  # P-value
  p_value <- 1 - pchisq(lrt_stat, df_chi2)
  
  # Store results
  lrt_results[i, ] <- c(log_likelihood_full, log_likelihood_nested, p_value)
}

#Print results in a data.frame
lrt_results_df <- data.frame(
  estimate = mle_result$par,
  LogLikelihoodFull = lrt_results[, 1],
  LogLikelihoodNested = lrt_results[, 2],
  PValue = lrt_results[, 3]
)

print(lrt_results_df) 

#output
#             estimate LogLikelihoodFull LogLikelihoodNested PValue
#tau      8.162318e-01          2394.904           -2389.011      0
#gammavar 6.481139e-05          2394.904           -2374.611      0



### model with interraction#######################################

set.seed(1111)
#Define the likelihood function
Ln_exp <- function(w, vcd, negative=FALSE){
  
  
  #coefficient
  mu <- exp(w[1] + w[2]*var)
  
  tau <- 1/(mu*w[3]) #shape par (a) =1/phi, scale par b = a/u =(1/phi)/u =1/(u*phi), where u=mu
  tau1 <- tau
  tau2 <- tau
  intcep <- w[1]
  coef <- w[2]
  phi <- w[3]
  gammavar <- exp(-9.644)
  v_cell<-(0.5^3)*pi/6
  vcd<-(tumsize^3)*pi/6
  if(negative)
    L <- -sum(log(tau1)+tau1*log(tau2)+log(gammavar)+(-(tau1+1))*log(tau2+gammavar*(vcd-v_cell)))
  else
    L <- sum(log(tau1)+tau1*log(tau2)+log(gammavar)+(-(tau1+1))*log(tau2+gammavar*(vcd-v_cell)))
  
  return(L)}

# Initial parameters
initial_params <- c(intcep = 0.1 , coef=0.1,  phi=0.1 )
#initial_params <- c(intcep = 0.01093994004, coef= -0.6539264674,  phi=0.56 )
set.seed(123)

# use optimization routine to find MLE
mle_result <- optim(
  par=initial_params, 
  negative=TRUE,
  fn = Ln_exp, 
  hessian = T
  #data=tumsize, 
  #method = "Nelder-Mead", 
  #control = list(maxit=1000, trace=T)
  )


print(mle_result$par)

#$par
#intcep         coef          phi 
#-0.015514171  0.008688804  1.355034874



#Bootstraps 95% confidence intervals
set.seed(111)
var1 <- var
tumsize1 <- tumsize
numberBoots <- 1000
bootNatural <- matrix(0,numberBoots,3)
for(n in 1:numberBoots){
  s <- sample(length(tumsize1), length(tumsize1), replace = TRUE)
  tumsize<-tumsize1[s]
  var<-var1[s]
  
  Ln_exp <- function(w, vcd, negative=FALSE){
    
    
    #coefficient
    mu <- exp(w[1] + w[2]*var)
    
    tau <- 1/(mu*w[3])
    tau1 <- tau
    tau2 <- tau
    intcep <- w[1]
    coef <- w[2]
    phi <- w[3]
    gammavar <- exp(-9.644)
    v_cell<-(0.5^3)*pi/6
    vcd<-(tumsize^3)*pi/6
    if(negative)
      L <- -sum(log(tau1)+tau1*log(tau2)+log(gammavar)+(-(tau1+1))*log(tau2+gammavar*(vcd-v_cell)))
    else
      L <- sum(log(tau1)+tau1*log(tau2)+log(gammavar)+(-(tau1+1))*log(tau2+gammavar*(vcd-v_cell)))
    
    return(L)
  }
  
  bootNatural[n,] <- optim(mle_result$par,Ln_exp,negative = TRUE)$par
}

#print parameter estimates and 95% confidence intervals of the parameters.
mle_result$par
sort(bootNatural[,1])[c(51,950)]
sort(bootNatural[,2])[c(51,950)]
sort(bootNatural[,3])[c(51,950)]



results_df <- data.frame(
  estimate = mle_result$par,
  CIs_par_1 = c(sort(bootNatural[,1])[51],sort(bootNatural[,2])[51],sort(bootNatural[,3])[51]),
  CIs_par_2 = c(sort(bootNatural[,1])[950],sort(bootNatural[,2])[950], sort(bootNatural[,3])[950])
)

print(results_df)
#output
#           estimate    CIs_par_1    CIs_par_2
#intcep -0.015514171 -0.36193260 0.33248618
#coef    0.008688804 -0.00638525 0.01996159
#phi     1.355034874  1.05589411 1.69846339


#####Likelihood Ratio Test
set.seed(134)
# Store log-likelihoods and perform Likelihood Ratio Test
lrt_results <- matrix(0, nrow = length(initial_params), ncol = 3)

for (i in seq_along(initial_params)) {
  # Create a copy of the initial parameters
  params_copy <- initial_params
  
  # Define the likelihood function for the null model (parameter fixed)
  Ln_exp_null <- function(w) {
    if (any(w <= 0)) return(-Inf)
    params_copy[i] <- w
    Ln_exp(params_copy, negative = TRUE)
  }
  
  # Log-likelihood for the full model
  log_likelihood_full <- Ln_exp(initial_params, negative = TRUE)
  
  # Log-likelihood for the nested model (with parameter fixed)
  tryCatch({
    log_likelihood_nested <- -optimize(Ln_exp_null, c(0.000001, 2), tol = 1e-6)$objective
  }, error = function(e) {
    cat("Warning: Optimization failed for the nested model with parameter ", names(initial_params)[i], "\n")
    log_likelihood_nested <- -Inf  # Set to -Inf in case of failure
  })
  
  # Likelihood ratio test statistic
  lrt_stat <- 2 * (log_likelihood_full - log_likelihood_nested)
  
  # Degrees of freedom for chi-squared distribution
  df_chi2 <- 1
  
  # P-value
  p_value <- 1 - pchisq(lrt_stat, df_chi2)
  
  # Store results
  lrt_results[i, ] <- c(log_likelihood_full, log_likelihood_nested, p_value)
}

# Print results in a data.frame
lrt_results_df <- data.frame(
  Parameter = names(initial_params),
  LogLikelihoodFull = lrt_results[, 1],
  LogLikelihoodNested = lrt_results[, 2],
  PValue = lrt_results[, 3]
)

# Display the Likelihood Ratio Test results
print("Likelihood Ratio Test Results:")
print(lrt_results_df)







