### Packages
library(glue)
library(haven)
library(tidyverse)

library(simsurv)
library(flexsurv)


#A=-0.0722
#B=1.18*10^(-3)
#delta=0.0952
#t = c(0,38:92)
#dens <- A*B*delta*(B-A)^delta*exp(delta*B*t)*(1-exp((B-A)*t))/((B*exp((B-A)*t)-A)^(delta+1))
#The probabilities are copied and presented below (dens).
# risk population is 0.045, thus no risk population is 0.955

dens <- c( 
  0.000000e+00, 1.331713e-03, 1.415129e-03, 1.501716e-03, 1.591403e-03, 1.684094e-03,
  1.779666e-03, 1.877970e-03, 1.978832e-03, 2.082050e-03, 2.187394e-03, 2.294613e-03,
  2.403429e-03, 2.513542e-03, 2.624634e-03, 2.736368e-03, 2.848396e-03, 2.960357e-03, 
  3.071887e-03, 3.182616e-03, 3.292179e-03, 3.400216e-03, 3.506376e-03, 3.610322e-03, 
  3.711737e-03, 3.810320e-03, 3.905799e-03, 3.997922e-03, 4.086470e-03, 4.171248e-03, 
  4.252094e-03, 4.328876e-03, 4.401489e-03, 4.469861e-03, 4.533945e-03, 4.593722e-03, 
  4.649199e-03, 4.700406e-03, 4.747393e-03, 4.790231e-03, 4.829006e-03, 4.863820e-03, 
  4.894789e-03, 4.922036e-03, 4.945695e-03, 4.965907e-03, 4.982816e-03, 4.996571e-03, 
  5.007322e-03, 5.015219e-03, 5.020412e-03, 5.023050e-03, 5.023279e-03, 5.021240e-03, 
  5.017073e-03, 5.010912e-03, 0.955)


## Generation of the disease in the population and when the clinical
## detection would occur in the absence of a screening program

natural_history_data <- function(A, B, delta, obs, tau1, tau2, BMI, d0, gam, popmort, year1, year2, bycohort, mybeta, cov, myknots, mult) {
  # no.obs.,screening ages, tau, gamma, sensitivity
  
  # NEED TO GENERATE AGE AT ONSET
  # ONSET CAN HAPPEN BETWEEN AGE 0 AND 55
  #dt =0.005
  t <-  c(0:55,NA)
  #dens <- A*B*delta*(B-A)^delta*exp(delta*B*t)*(1-exp((B-A)*t))/((B*exp((B-A)*t)-A)^(delta+1))
  
  # simulate birth cohorts
  bornyear <- rep(seq(year1, year2, bycohort), obs) 
  totobs <- length(bornyear)
  # output:
  # bornyear=year of birth
  # simulating 'obs' births into the population every year, from 'year1' to 'year2'
  
  
  atumon <- (sample(x = t, size = totobs, replace = TRUE, prob = dens)) ## sample of onsettimes
  # output:
  # atumon=age at start of tumour growth
  
  # Only keep if having onset
  index <- which(!is.na(atumon))
  nobs <- length(index)

  
  # Make dataset
  simdf <- tibble::tibble(
    lopnr = seq(nobs),
    
    bornyear = bornyear[index],
    atumon = atumon[index]
  )
  
  
  #generate BMI 18.5-24.9
  simdf$BMI = rnorm(nobs, mean =  21.5 , sd = 0.50) 
  
  mu <- exp(-0.015 + 0.009*simdf$BMI)
  tau1 <- 1/(mu*1.355)
  tau2 <- tau1
  # output:
  # lopnr = id number for each subject
  
  # Tumour growth rates
  simdf$grr <- stats::rgamma(nobs, shape = tau1, scale = 1 / tau2) ## inverse growth rates
  # output:
  # grr=inverse growth rate
  
  # Tumour volumes at clinical detection
  v0 <- (1 / 6) * pi * (d0^3) # v0 in vcell in the formulae, volume of a cell of diameter d0 = 0.5 mm
  u <- stats::runif(n = nobs)
  simdf$vcd <- v0 - (log(1 - u)) / (gam * simdf$grr) # volume
  simdf$sizesymp <- (6 * simdf$vcd / pi)^(1 / 3) # turns the volumes 'vcd' into diameters
  # output:
  # sizesymp = tumour sizes at clinical detection (diameter)
  
  # age at clinical detection
  simdf$agesymp <- simdf$atumon + simdf$grr * log(simdf$vcd / v0) # atumon + formula 11, but written as t = ...
  # output:
  # agesymp = age at clinical detection
  # age at clinical detection
  simdf$agesymp <- simdf$atumon + simdf$grr * log(simdf$vcd / v0) # atumon + formula 11, but written as t = ...
  # output:
  # agesymp = age at clinical detection
  
  # a few extra variables
  simdf$yearsymp <- floor(simdf$agesymp + simdf$bornyear)
  simdf$yeartumon <- floor(simdf$atumon + simdf$bornyear)
  # output:
  # yeartumon=calendar year at start of tumour growth
  # yearsymp=calendar year at symptomatic detection
  # allobs=total number of simulated observations
  # obscohort=number of simulated individuals per birth cohort
  
  # return the data
  return(simdf)
}

############################################
# Now find screening detected tumors
############################################

# sts computes screening sensitivity
sts <- function(.size, .beta1, .beta2) { # size here is diameter of the tumour
  STS <- exp(.beta1 + .beta2 * .size) / (1 + exp(.beta1 + .beta2 * .size))
  return(STS)
}

impose_screening <- function(aa, a1, au, beta1, beta2, byyr, v0, perfect_screening) {
  nobs <- nrow(aa)
  
  sizedet <- rep(NA, nobs)
  diamam <- rep(0, nobs)
  agedet <- rep(NA, nobs)
  yeardet <- rep(NA, nobs)
  
  # first diagnose those who will not have cancer during screening
  # these are people that already had symptoms (were diagnosed/detected) before age of 40, when screening started
  i0 <- which((diamam == 0) & (aa$agesymp <= a1))
  sizedet[i0] <- aa$sizesymp[i0]
  diamam[i0] <- 1
  agedet[i0] <- aa$agesymp[i0]
  yeardet[i0] <- aa$yearsymp[i0]
  
  # first diagnose those who will not have cancer during screening
  # these are people that didn't have cancer yet
  i0 <- which((diamam == 0) & (aa$atumon > au))
  sizedet[i0] <- aa$sizesymp[i0]
  diamam[i0] <- 5
  agedet[i0] <- aa$agesymp[i0]
  yeardet[i0] <- aa$yearsymp[i0]
  
  # screening
  if (perfect_screening) {
    attender <- rep(1, nobs)
    p_attending_a_visit <- rep(1, nobs)
  } else {
    # there is a 80 percent probability of attending screening
    attender <- rbinom(n = nobs, size = 1, prob = 0.8)
    # Among those who have a high probability to attend screening (attender=1), there is 90 percent probability of attending a specific visit tt
    # Among those who have a low probability to attend screening (attender=0), there is 15 percent probability of attending a specific visit tt
    p_attending_a_visit <- ifelse(attender == 0, 0.15, 0.9)
  }
  
  # loop through those who might be detected during screening
  for (tt in seq(a1, au, by = byyr)) {
    
    
    # those that have not yet been diagnosed, but have symp detection before time tt
    i1 <- which((diamam == 0) & (aa$atumon <= tt) & (tt >= aa$agesymp))
    sizedet[i1] <- aa$sizesymp[i1]
    diamam[i1] <- 2
    agedet[i1] <- aa$agesymp[i1]
    yeardet[i1] <- aa$yearsymp[i1]
    
    # those that have not yet been diagnosed, and have an undiagnosed tumor
    i2 <- which((diamam == 0) & (aa$atumon <= tt) & (tt < aa$agesymp))
    if (length(i2) > 0) {
      for (a in 1:length(i2)) {
        vnow <- (pi * (v0^3) / 6) * exp((tt - aa$atumon[i2[a]]) / aa$grr[i2[a]]) # calculate volume of tumour at current screen
        sizenow <- (6 * vnow / pi)^(1 / 3) # turn volume into diameter
        tmp <- sts(.size = sizenow, .beta1 = beta1, .beta2 = beta2) # calculate screening sensitivity: P(being detected by screening with a tumour of diameter 'sizenow' when screened at age 'tt')
        attended_this_visit <- rbinom(n = 1, size = 1, prob = p_attending_a_visit[i2[a]])
        tmp <- tmp * attended_this_visit
        u <- stats::runif(n = 1)
        # kind of equivalent to detected = rbinom(n = 1, size = 1, prob = tmp), Bernoulli(tmp)
        if (u < tmp) { # if u smaller than tmp -> screen detection!
          sizedet[i2[a]] <- sizenow
          diamam[i2[a]] <- 3
          agedet[i2[a]] <- tt
          yeardet[i2[a]] <- floor(aa$bornyear[i2[a]] + tt)
        }
      }
    }
    # now loop for the next screen age
  }
  
  # now those that have been in screening but not yet diagnosed
  # these are people with a tumour, not detected yet by screening, not detected yet by symptoms
  i3 <- which((diamam == 0) & (!is.na(aa$atumon)))
  sizedet[i3] <- aa$sizesymp[i3]
  diamam[i3] <- 4
  agedet[i3] <- aa$agesymp[i3]
  yeardet[i3] <- aa$yearsymp[i3]
  
  # save characteristics of the screening process and return
  nn <- tibble::tibble(aa, sizedet, diamam, agedet, yeardet)
  return(nn)
}





# first distribute the probabilities of onset at different ages
# from incidence 1973
#A=-0.0722
#B=1.18*10^(-3)
#delta=0.0952

# parameter values for the rate of symp
gammavar <- 9.644 # eta in the formulae
gam <- exp(-gammavar)
d0 <- 0.5 # diameter


# observations and birth cohorts
nnobs <- 5000
year1 <- 1985
year2 <- 2020
bycohort <- 1

# screening interval
a1 <- 30
au <- 65

byyear1 <- 1
byyear2 <- 2
byyear3 <- 3


# screening parameters for moderate screening
beta1_1 <- -5.04
beta2_1 <- 0.56

# screening parameters for low screening
beta1_2 <- -5.45
beta2_2 <- 0.48

# screening parameters for high screening
beta1_3 <- -4.67
beta2_3 <- 0.65

# set seed for reproducibility
set.seed(165)
# do B replicates
B <- 25

# Setup progress bar
pb <- utils::txtProgressBar(min = 0, max = B, style = 3)
for (i in seq(B)) {
  
  # Base data
  #qq1 <- natural_history_data(A=A, B=B, delta= delta, obs = nnobs, tau1 = tau1, tau2 = tau2, BMI = BMI_u, d0 = d0, gam = gam, popmort = popmort, year1 = year1, year2 = year2, bycohort = bycohort, mybeta = mybeta, cov = cov, myknots = myknots, mult = fact)
  qq2 <- natural_history_data(A=A, B=B, delta= delta, obs = nnobs, tau1 = tau1, tau2 = tau2, BMI = BMI_n, d0 = d0, gam = gam, popmort = popmort, year1 = year1, year2 = year2, bycohort = bycohort, mybeta = mybeta, cov = cov, myknots = myknots, mult = fact)
  #qq3 <- natural_history_data(A=A, B=B, delta= delta, obs = nnobs, tau1 = tau1, tau2 = tau2, BMI = BMI_o, d0 = d0, gam = gam, popmort = popmort, year1 = year1, year2 = year2, bycohort = bycohort, mybeta = mybeta, cov = cov, myknots = myknots, mult = fact)# Screening scenario 1
  
  # Screening scenario 1
  rr_1_perfect <- impose_screening(aa = qq2, a1 = a1, au = au, beta1 = beta1_1, beta2 = beta2_1, byyr = byyear1, v0 = d0, perfect_screening = TRUE)
  rr_1_imperfect <- impose_screening(aa = qq2, a1 = a1, au = au, beta1 = beta1_1, beta2 = beta2_1, byyr = byyear1, v0 = d0, perfect_screening = FALSE)
  
  # Screening scenario 2
  rr_2_perfect <- impose_screening(aa = qq2, a1 = a1, au = au, beta1 = beta1_1, beta2 = beta2_1, byyr = byyear2, v0 = d0, perfect_screening = TRUE)
  rr_2_imperfect <- impose_screening(aa = qq2, a1 = a1, au = au, beta1 = beta1_1, beta2 = beta2_1, byyr = byyear2, v0 = d0, perfect_screening = FALSE)
  
  # Screening scenario 3
  rr_3_perfect <- impose_screening(aa = qq2, a1 = a1, au = au, beta1 = beta1_1, beta2 = beta2_1, byyr = byyear3, v0 = d0, perfect_screening = TRUE)
  rr_3_imperfect <- impose_screening(aa = qq2, a1 = a1, au = au, beta1 = beta1_1, beta2 = beta2_1, byyr = byyear3, v0 = d0, perfect_screening = FALSE)
  
  
  # Combine into a single dataset with the three scenarios, in wide format
  # First, prepare files to be joined
  rr_1_perfect <- dplyr::rename(rr_1_perfect, sizedet_1_perfect = sizedet, diamam_1_perfect = diamam, agedet_1_perfect = agedet, yeardet_1_perfect = yeardet)
  rr_1_imperfect <- dplyr::select(rr_1_imperfect, lopnr, sizedet, diamam, agedet, yeardet) %>%
    dplyr::rename(sizedet_1_imperfect = sizedet, diamam_1_imperfect = diamam, agedet_1_imperfect = agedet, yeardet_1_imperfect = yeardet)
  
  rr_2_perfect <- dplyr::select(rr_2_perfect, lopnr, sizedet, diamam, agedet, yeardet) %>%
    dplyr::rename(sizedet_2_perfect = sizedet, diamam_2_perfect = diamam, agedet_2_perfect = agedet, yeardet_2_perfect = yeardet)
  rr_2_imperfect <- dplyr::select(rr_2_imperfect, lopnr, sizedet, diamam, agedet, yeardet) %>%
    dplyr::rename(sizedet_2_imperfect = sizedet, diamam_2_imperfect = diamam, agedet_2_imperfect = agedet, yeardet_2_imperfect = yeardet)
  
  rr_3_perfect <- dplyr::select(rr_3_perfect, lopnr, sizedet, diamam, agedet, yeardet) %>%
    dplyr::rename(sizedet_3_perfect = sizedet, diamam_3_perfect = diamam, agedet_3_perfect = agedet, yeardet_3_perfect = yeardet)
  rr_3_imperfect <- dplyr::select(rr_3_imperfect, lopnr, sizedet, diamam, agedet, yeardet) %>%
    dplyr::rename(sizedet_3_imperfect = sizedet, diamam_3_imperfect = diamam, agedet_3_imperfect = agedet, yeardet_3_imperfect = yeardet)
  # Then, join them
  rr <- dplyr::left_join(rr_1_perfect, rr_1_imperfect, by = "lopnr") %>%
    dplyr::left_join(rr_2_perfect, by = "lopnr") %>%
    dplyr::left_join(rr_2_imperfect, by = "lopnr") %>%
    dplyr::left_join(rr_3_perfect, by = "lopnr") %>%
    dplyr::left_join(rr_3_imperfect, by = "lopnr")
  
  # Now, export in Stata or SPSS format
  #haven::write_dta(data = rr, path = glue::glue("dta/simdata_wide_{i}.dta"))
  haven::write_sav(data = rr, path = glue::glue("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Personalized_BMI_n/simdata_wide_{i}.sav")) 
  # Advance progress bar
  utils::setTxtProgressBar(pb = pb, value = i)
}
close(pb)
