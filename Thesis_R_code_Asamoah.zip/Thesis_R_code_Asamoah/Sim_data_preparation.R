rm(list=ls())
library(haven)
library(usethis)
library(devtools)
library(dplyr)

#Set work directory to the folder where your data is saved
setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Scenarios")
# List all the files in the folder
files <- list.files()

# Create an empty data frame to store the results
results_df <- data.frame(Attendance = character(), 
                         Method = character(),
                         No_screen = character(),
                         Screen = character(),
                         prop_screen_detected = character(),
                         prop_interval_cases = character(),
                         stringsAsFactors =FALSE)

data_det1 <- list()
data_det2 <- list()
data_det3 <- list()
data_det11 <- list()
data_det22 <- list()
data_det33 <- list()
data_symp <- list()
results_list <-list()
# loop through each file in the folder
for (file in files) {
  #read the data
  data <- haven::read_sav(file)
  
 
  # Filter the data for screening age
  data_det1 <- subset(data, (agedet_1_imperfect >= 40 & agedet_1_imperfect <= 74))
  data_det2 <- subset(data, (agedet_2_imperfect >= 40 & agedet_2_imperfect <= 74))
  data_det3 <- subset(data, (agedet_3_imperfect >= 40 & agedet_3_imperfect <= 74))
  data_det11 <- subset(data, (agedet_1_perfect >= 40 & agedet_1_perfect <= 74))
  data_det22 <- subset(data, (agedet_2_perfect >= 40 & agedet_2_perfect <= 74))
  data_det33 <- subset(data, (agedet_3_perfect >= 40 & agedet_3_perfect <= 74))
  data_symp <- subset(data, (agesymp >= 40 & agesymp <= 74))
  
  #calculate the frequency of symp and screen detection
  freq_method1_p0 <- sum(sum(data_symp$diamam_1_imperfect == 1), sum(data_symp$diamam_1_imperfect == 2), sum(data_symp$diamam_1_imperfect == 3), sum(data_symp$diamam_1_imperfect == 4), sum(data_symp$diamam_1_imperfect == 5))
  freq_method2_p0 <- sum(sum(data_symp$diamam_2_imperfect == 1), sum(data_symp$diamam_2_imperfect == 2), sum(data_symp$diamam_2_imperfect == 3), sum(data_symp$diamam_2_imperfect == 4), sum(data_symp$diamam_2_imperfect == 5))
  freq_method3_p0 <- sum(sum(data_symp$diamam_3_imperfect == 1), sum(data_symp$diamam_3_imperfect == 2), sum(data_symp$diamam_3_imperfect == 3),sum(data_symp$diamam_3_imperfect == 4), sum(data_symp$diamam_3_imperfect == 5))
  
  freq_method1_p1 <- sum(sum(data_symp$diamam_1_perfect == 1), sum(data_symp$diamam_1_perfect == 2), sum(data_symp$diamam_1_perfect == 3), sum(data_symp$diamam_1_perfect == 4), sum(data_symp$diamam_1_perfect == 5))
  freq_method2_p1 <- sum(sum(data_symp$diamam_2_perfect == 1), sum(data_symp$diamam_2_perfect == 2), sum(data_symp$diamam_2_perfect == 3), sum(data_symp$diamam_2_perfect == 4), sum(data_symp$diamam_2_perfect == 5))
  freq_method3_p1 <- sum(sum(data_symp$diamam_3_perfect == 1), sum(data_symp$diamam_3_perfect == 2), sum(data_symp$diamam_3_perfect == 3), sum(data_symp$diamam_3_perfect == 4), sum(data_symp$diamam_3_perfect == 5))
  
  freq_method1_p00 <- sum(sum(data_det1$diamam_1_imperfect == 2),sum(data_det1$diamam_1_imperfect == 3))
  freq_method2_p00 <- sum(sum(data_det2$diamam_2_imperfect == 2),sum(data_det2$diamam_2_imperfect == 3))
  freq_method3_p00 <- sum(sum(data_det3$diamam_3_imperfect == 2),sum(data_det3$diamam_3_imperfect == 3))
  
  freq_method1_p11 <- sum(sum(data_det11$diamam_1_perfect == 2),sum(data_det11$diamam_1_perfect == 3))
  freq_method2_p11 <- sum(sum(data_det22$diamam_2_perfect == 2),sum(data_det22$diamam_2_perfect == 3))
  freq_method3_p11 <- sum(sum(data_det33$diamam_3_perfect == 2),sum(data_det33$diamam_3_perfect == 3))
  
  #calculate the proportion by detection mode for screening
  freq_method1_p00_prop3 <- sum(data_det1$diamam_1_imperfect == 3)/sum(sum(data$diamam_1_imperfect == 1),sum(data$diamam_1_imperfect == 2),sum(data$diamam_1_imperfect == 3), sum(data$diamam_1_imperfect == 4), sum(data$diamam_1_imperfect == 5))
  freq_method2_p00_prop3 <- sum(data_det2$diamam_2_imperfect == 3)/sum(sum(data$diamam_2_imperfect == 1),sum(data$diamam_2_imperfect == 2),sum(data$diamam_2_imperfect == 3), sum(data$diamam_2_imperfect == 4), sum(data$diamam_2_imperfect == 5))
  freq_method3_p00_prop3 <- sum(data_det3$diamam_3_imperfect == 3)/sum(sum(data$diamam_3_imperfect == 1),sum(data$diamam_3_imperfect == 2),sum(data$diamam_3_imperfect == 3), sum(data$diamam_3_imperfect == 4), sum(data$diamam_3_imperfect == 5))
  
  freq_method1_p11_prop3 <- sum(data_det11$diamam_1_perfect == 3)/sum(sum(data$diamam_1_perfect == 1),sum(data$diamam_1_perfect == 2),sum(data$diamam_1_perfect == 3), sum(data$diamam_1_perfect == 4), sum(data$diamam_1_perfect == 5))
  freq_method2_p11_prop3 <- sum(data_det22$diamam_2_perfect == 3)/sum(sum(data$diamam_2_perfect == 1), sum(data$diamam_2_perfect == 2),sum(data$diamam_2_perfect == 3),sum(data$diamam_2_perfect == 4), sum(data$diamam_2_perfect == 5))
  freq_method3_p11_prop3 <- sum(data_det33$diamam_3_perfect == 3)/sum(sum(data$diamam_3_perfect == 1), sum(data$diamam_3_perfect == 2),sum(data$diamam_3_perfect == 3), sum(data$diamam_3_perfect == 4),sum(data$diamam_3_perfect == 5))
  
  freq_method1_p00_prop2 <- sum(data_det1$diamam_1_imperfect == 2)/sum(sum(data$diamam_1_imperfect == 1), sum(data$diamam_1_imperfect == 2),sum(data$diamam_1_imperfect == 3), sum(data$diamam_1_imperfect == 4), sum(data$diamam_1_imperfect == 5))
  freq_method2_p00_prop2 <- sum(data_det2$diamam_2_imperfect == 2)/sum(sum(data$diamam_2_imperfect == 1), sum(data$diamam_2_imperfect == 2),sum(data$diamam_2_imperfect == 3), sum(data$diamam_2_imperfect == 4), sum(data$diamam_2_imperfect == 5))
  freq_method3_p00_prop2 <- sum(data_det3$diamam_3_imperfect == 2)/sum(sum(data$diamam_3_imperfect == 1), sum(data$diamam_3_imperfect == 2),sum(data$diamam_3_imperfect == 3), sum(data$diamam_3_imperfect == 4), sum(data$diamam_3_imperfect == 5))
  
  freq_method1_p11_prop2 <- sum(data_det11$diamam_1_perfect == 2)/sum(sum(data$diamam_1_perfect == 1),sum(data$diamam_1_perfect == 2),sum(data$diamam_1_perfect == 3), sum(data$diamam_1_perfect == 4), sum(data$diamam_1_perfect == 5))
  freq_method2_p11_prop2 <- sum(data_det22$diamam_2_perfect == 2)/sum(sum(data$diamam_2_perfect == 1),sum(data$diamam_2_perfect == 2),sum(data$diamam_2_perfect == 3), sum(data$diamam_2_perfect == 4), sum(data$diamam_2_perfect == 5))
  freq_method3_p11_prop2 <- sum(data_det33$diamam_3_perfect == 2)/sum(sum(data$diamam_3_perfect == 1),sum(data$diamam_3_perfect == 2),sum(data$diamam_3_perfect == 3),sum(data$diamam_3_perfect == 4), sum(data$diamam_3_perfect == 5))
  
   results_df <- rbind(results_df, 
                      data.frame(Attendance = rep(c("0", "1"), each =3),
                                 Method = rep(c("1", "2", "3"), times = 2),
                                 No_screen = c(freq_method2_p0, freq_method2_p1, 
                                               freq_method1_p0, freq_method1_p1,
                                               freq_method3_p0, freq_method3_p1), 
                                 screen = c(freq_method2_p00, freq_method2_p11, 
                                            freq_method1_p00, freq_method1_p11,
                                            freq_method3_p00, freq_method3_p11),
                                 prop_screen_detected = c(freq_method2_p00_prop3, freq_method2_p11_prop3, 
                                                          freq_method1_p00_prop3, freq_method1_p11_prop3,
                                                          freq_method3_p00_prop3, freq_method3_p11_prop3),
                                 prop_interval_cases = c(freq_method2_p00_prop2, freq_method2_p11_prop2, 
                                                          freq_method1_p00_prop2, freq_method1_p11_prop2,
                                                          freq_method3_p00_prop2, freq_method3_p11_prop2),
                                
                                 stringsAsFactors =FALSE))
  
  results_list[[file]] <- results_df
}

# calculate the overall frequency across all simulations
#create a new column ID
i <- rep(seq_len(nrow(results_df)/6), each = 6)
overall_freq <- results_df %>%
  group_by( Attendance, Method) 

out1 <- tibble::tibble(i,overall_freq)
#out1$p <-out1$prop_screen_detected*100
#Print results
#print(out1)

mean_data <- aggregate(cbind(No_screen, screen, prop_screen_detected, prop_interval_cases) ~ Attendance+ Method, data = out1, FUN = mean)

print(mean_data)

#write.csv(mean_data,file="C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Scenarios.csv",row.names = F)






#selection of screen age
#Set work directory to the folder where your data is saved
#change work directory
setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Scr_ages")


# List all the files in the folder
files <- list.files()

# Create an empty data frame to store the results
results_df <- data.frame(Attendance = character(), 
                         Method = character(),
                         No_screen = character(),
                         Screen = character(),
                         prop_screen_detected = character(),
                         prop_interval_cases = character(),
                         
                         stringsAsFactors =FALSE)

data_det1 <- list()
data_symp1 <- list()
data_det2 <- list()
data_symp2 <- list()
data_det3 <- list()
data_symp3 <- list()
results_list <-list()
# loop through each file in the folder
for (file in files) {
  #read the data
  data <- haven::read_sav(file)
  
  # Filter the data for screen ages
  data_det1 <- subset(data, (agedet_1_imperfect >= 35 & agedet_1_imperfect <= 60))
  data_symp1 <- subset(data, (agesymp >= 35 & agesymp <= 60) & (agedet_1_imperfect >= 35 & agedet_1_imperfect <= 60))
  
  data_det2 <- subset(data, (agedet_2_imperfect >= 30 & agedet_2_imperfect <= 60))
  data_symp2 <- subset(data, (agesymp >= 30 & agesymp <= 60) & (agedet_2_imperfect >= 30 & agedet_2_imperfect <= 60))
  
  data_det3 <- subset(data, (agedet_3_imperfect >= 25 & agedet_3_imperfect <= 60))
  data_symp3 <- subset(data, (agesymp >= 25 & agesymp <= 60) & (agedet_1_imperfect >= 25 & agedet_3_imperfect <= 60))
  
  
  #calculate the frequency of symp and screen detection
  
  freq_method1_p0 <- sum(sum(data_symp1$diamam_1_imperfect == 1), sum(data_symp1$diamam_1_imperfect == 2), sum(data_symp1$diamam_1_imperfect == 3), sum(data_symp1$diamam_1_imperfect == 4), sum(data_symp1$diamam_1_imperfect == 5))
  freq_method2_p0 <- sum(sum(data_symp2$diamam_2_imperfect == 1), sum(data_symp2$diamam_2_imperfect == 2), sum(data_symp2$diamam_2_imperfect == 3), sum(data_symp2$diamam_2_imperfect == 4), sum(data_symp2$diamam_2_imperfect == 5))
  freq_method3_p0 <- sum(sum(data_symp3$diamam_3_imperfect == 1), sum(data_symp3$diamam_3_imperfect == 2), sum(data_symp3$diamam_3_imperfect == 3),sum(data_symp3$diamam_3_imperfect == 4), sum(data_symp3$diamam_3_imperfect == 5))
  
  freq_method1_p00 <- sum(sum(data_det1$diamam_1_imperfect == 2),sum(data_det1$diamam_1_imperfect == 3))
  freq_method2_p00 <- sum(sum(data_det2$diamam_2_imperfect == 2),sum(data_det2$diamam_2_imperfect == 3))
  freq_method3_p00 <- sum(sum(data_det3$diamam_3_imperfect == 2),sum(data_det3$diamam_3_imperfect == 3))
  
  
  
  freq_method1_p00_prop3 <- sum(data_det1$diamam_1_imperfect == 3)/sum(sum(data$diamam_1_imperfect == 1),sum(data$diamam_1_imperfect == 2),sum(data$diamam_1_imperfect == 3), sum(data$diamam_1_imperfect == 4), sum(data$diamam_1_imperfect == 5))
  freq_method2_p00_prop3 <- sum(data_det2$diamam_2_imperfect == 3)/sum(sum(data$diamam_2_imperfect == 1),sum(data$diamam_2_imperfect == 2),sum(data$diamam_2_imperfect == 3), sum(data$diamam_2_imperfect == 4), sum(data$diamam_2_imperfect == 5))
  freq_method3_p00_prop3 <- sum(data_det3$diamam_3_imperfect == 3)/sum(sum(data$diamam_3_imperfect == 1),sum(data$diamam_3_imperfect == 2),sum(data$diamam_3_imperfect == 3), sum(data$diamam_3_imperfect == 4), sum(data$diamam_3_imperfect == 5))
  
  freq_method1_p00_prop2 <- sum(data_det1$diamam_1_imperfect == 2)/sum(sum(data$diamam_1_imperfect == 1), sum(data$diamam_1_imperfect == 2),sum(data$diamam_1_imperfect == 3), sum(data$diamam_1_imperfect == 4), sum(data$diamam_1_imperfect == 5))
  freq_method2_p00_prop2 <- sum(data_det2$diamam_2_imperfect == 2)/sum(sum(data$diamam_2_imperfect == 1), sum(data$diamam_2_imperfect == 2),sum(data$diamam_2_imperfect == 3), sum(data$diamam_2_imperfect == 4), sum(data$diamam_2_imperfect == 5))
  freq_method3_p00_prop2 <- sum(data_det3$diamam_3_imperfect == 2)/sum(sum(data$diamam_3_imperfect == 1), sum(data$diamam_3_imperfect == 2),sum(data$diamam_3_imperfect == 3), sum(data$diamam_3_imperfect == 4), sum(data$diamam_3_imperfect == 5))
  
  
  results_df <- rbind(results_df, 
                      data.frame(Attendance = rep(c("0"), each =3),
                                 Method = rep(c("1", "2", "3"), times = 1),
                                 No_screen = c(freq_method1_p0,  
                                               freq_method2_p0, 
                                               freq_method3_p0), 
                                 screen = c(freq_method1_p00, 
                                            freq_method2_p00,
                                            freq_method3_p00),
                                 prop_screen_detected = c(freq_method1_p00_prop3, 
                                                          freq_method2_p00_prop3,
                                                          freq_method3_p00_prop3),
                                 prop_interval_cases = c(freq_method1_p00_prop2, 
                                                         freq_method2_p00_prop2,
                                                         freq_method3_p00_prop2),
                                 
                                 stringsAsFactors =FALSE))
  
  results_list[[file]] <- results_df
}
# calculate the overall frequency across all simulations
#create a new column ID
i <- rep(seq_len(nrow(results_df)/3), each = 3)
overall_freq <- results_df %>%
  group_by( Attendance, Method) 

out1 <- tibble::tibble(i,overall_freq)
#out1$p <-out1$prop_screen_detected*100
#Print results
#print(out1)

mean_data <- aggregate(cbind(No_screen, screen, prop_screen_detected, prop_interval_cases
                             ) ~ Attendance+ Method, data = out1, FUN = mean)

print(mean_data)

#write.csv(mean_data,file="C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Scr_ages.csv",row.names = F)


#selection of screening interval
#Set work directory to the folder where your data is saved
setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Scr_interval")
setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Personalized_BMI_u")


# List all the files in the folder
files <- list.files()

# Create an empty data frame to store the results
results_df <- data.frame(Attendance = character(), 
                         Method = character(),
                         No_screen = character(),
                         Screen = character(),
                         prop_screen_detected = character(),
                         prop_interval_cases = character(),
                         stringsAsFactors =FALSE)

data_det1 <- list()
data_det2 <- list()
data_det3 <- list()
data_symp1 <- list()
data_symp2 <- list()
data_symp3 <- list()
results_list <-list()
# loop through each file in the folder
for (file in files) {
  #read the data
  data <- haven::read_sav(file)
  
  
  
  # Filter the data for screen interval 
  # 1_imperfect is year 1, 2_imperfect is year 2, 3_imperfect is year 3
  data_det1 <- subset(data, (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65))
  data_symp1 <- subset(data, (agesymp >= 30 & agesymp <= 65) & (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65))
  
  data_det2 <- subset(data, (agedet_2_imperfect >= 30 & agedet_2_imperfect <= 65))
  data_symp2 <- subset(data, (agesymp >= 30 & agesymp <= 65) & (agedet_2_imperfect >= 30 & agedet_2_imperfect <= 65))
  
  data_det3 <- subset(data, (agedet_3_imperfect >= 30 & agedet_3_imperfect <= 65))
  data_symp3 <- subset(data, (agesymp >= 30 & agesymp <= 65) & (agedet_1_imperfect >= 30 & agedet_3_imperfect <= 65))
  
  
  
  #calculate the frequency of symp and screen detection
    
  freq_method1_p0 <- sum(sum(data_symp1$diamam_1_imperfect == 1), sum(data_symp1$diamam_1_imperfect == 2),sum(data_symp1$diamam_1_imperfect == 3), sum(data_symp1$diamam_1_imperfect == 4), sum(data_symp1$diamam_1_imperfect == 5))
  freq_method2_p0 <- sum(sum(data_symp2$diamam_2_imperfect == 1), sum(data_symp2$diamam_2_imperfect == 2), sum(data_symp2$diamam_2_imperfect == 3), sum(data_symp2$diamam_2_imperfect == 4), sum(data_symp2$diamam_2_imperfect == 5))
  freq_method3_p0 <- sum(sum(data_symp3$diamam_3_imperfect == 1), sum(data_symp3$diamam_3_imperfect == 2), sum(data_symp3$diamam_3_imperfect == 3), sum(data_symp3$diamam_3_imperfect == 4), sum(data_symp3$diamam_3_imperfect == 5))

  freq_method1_p00 <- sum(sum(data_det1$diamam_1_imperfect == 2),sum(data_det1$diamam_1_imperfect == 3))
  freq_method2_p00 <- sum(sum(data_det2$diamam_2_imperfect == 2),sum(data_det2$diamam_2_imperfect == 3))
  freq_method3_p00 <- sum(sum(data_det3$diamam_3_imperfect == 2),sum(data_det3$diamam_3_imperfect == 3))

  #calculate the proportion by detection mode for screening
  freq_method1_p00_prop3 <- sum(data_det1$diamam_1_imperfect == 3)/sum(sum(data$diamam_1_imperfect == 1), sum(data$diamam_1_imperfect == 2), sum(data$diamam_1_imperfect == 3), sum(data$diamam_1_imperfect == 4), sum(data$diamam_1_imperfect == 5))
  freq_method2_p00_prop3 <- sum(data_det2$diamam_2_imperfect == 3)/sum(sum(data$diamam_2_imperfect == 1), sum(data$diamam_2_imperfect == 2), sum(data$diamam_2_imperfect == 3), sum(data$diamam_2_imperfect == 4), sum(data$diamam_2_imperfect == 5))
  freq_method3_p00_prop3 <- sum(data_det3$diamam_3_imperfect == 3)/sum(sum(data$diamam_3_imperfect == 1), sum(data$diamam_3_imperfect == 2), sum(data$diamam_3_imperfect == 3), sum(data$diamam_3_imperfect == 4), sum(data$diamam_3_imperfect == 5))

  
  freq_method1_p00_prop2 <- sum(data_det1$diamam_1_imperfect == 2)/sum(sum(data$diamam_1_imperfect == 1), sum(data$diamam_1_imperfect == 2), sum(data$diamam_1_imperfect == 3), sum(data$diamam_1_imperfect == 4), sum(data$diamam_1_imperfect == 5))
  freq_method2_p00_prop2 <- sum(data_det2$diamam_2_imperfect == 2)/sum(sum(data$diamam_2_imperfect == 1), sum(data$diamam_2_imperfect == 2), sum(data$diamam_2_imperfect == 3), sum(data$diamam_2_imperfect == 4), sum(data$diamam_2_imperfect == 5))
  freq_method3_p00_prop2 <- sum(data_det3$diamam_3_imperfect == 2)/sum(sum(data$diamam_3_imperfect == 1), sum(data$diamam_3_imperfect == 2), sum(data$diamam_3_imperfect == 3),sum(data$diamam_3_imperfect == 4), sum(data$diamam_3_imperfect == 5))

  
  results_df <- rbind(results_df, 
                      data.frame(Attendance = rep(c("0"), each =3),
                                 Method = rep(c("1", "2", "3"), times = 1),
                                 No_screen = c(freq_method1_p0,  
                                               freq_method2_p0, 
                                               freq_method3_p0), 
                                 screen = c(freq_method1_p00, 
                                            freq_method2_p00,
                                            freq_method3_p00),
                                 prop_screen_detected = c(freq_method1_p00_prop3, 
                                                          freq_method2_p00_prop3,
                                                          freq_method3_p00_prop3),
                                 prop_interval_cases = c(freq_method1_p00_prop2, 
                                                         freq_method2_p00_prop2,
                                                         freq_method3_p00_prop2),
                                 stringsAsFactors =FALSE))
  
  results_list[[file]] <- results_df
}
# calculate the overall frequency across all simulations
#create a new column ID
i <- rep(seq_len(nrow(results_df)/3), each = 3)
overall_freq <- results_df %>%
  group_by( Attendance, Method) 

out1 <- tibble::tibble(i,overall_freq)
#out1$p <-out1$prop_screen_detected*100
#Print results
#print(out1)

mean_data <- aggregate(cbind(No_screen, screen, prop_screen_detected, prop_interval_cases
                             ) ~ Attendance+ Method, data = out1, FUN = mean)

print(mean_data)
#write.csv(mean_data,file="C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Scr_interval.csv",row.names = F)


#Optimal Screening 
#Set work directory to the folder where your data is saved
setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Optimal")
setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Personalized_mod")


library("tidyverse")
# List all the files in the folder
files <- list.files()

# Create an empty data frame to store the results
results_df <- data.frame(Summary = character(), 
                         No_screen = character(),
                         Screen = character(),
                         stringsAsFactors =FALSE)

data_det <- list()
data_symp <- list()
results_list <-list()
# loop through each file in the folder
for (file in files) {
  #read the data
  data2 <- haven::read_sav(file)

  # Filter the data
  data_det <- subset(data2, (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65))
  data_symp <- subset(data2, (agesymp >= 30 & agesymp <= 65) & (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65))
  
  ##
  #calculate the frequency of symp and screen detection
  freq_method2_p0 <- sum(sum(data_symp$diamam_1_imperfect == 1), sum(data_symp$diamam_1_imperfect == 2), sum(data_symp$diamam_1_imperfect == 3),
                         sum(data_symp$diamam_1_imperfect == 4), sum(data_symp$diamam_1_imperfect == 5))
  freq_method2_p00 <- sum(sum(data_det$diamam_1_imperfect == 2), sum(data_det$diamam_1_imperfect == 3))
                                                            
  
  # Filter data for tumor size 2 and 3
  agesymp_0_1 <- data_symp$agesymp[data_symp$diamam_1_imperfect == 1 | data_symp$diamam_1_imperfect == 2| data_symp$diamam_1_imperfect == 3| 
                                         data_symp$diamam_1_imperfect == 4 | data_symp$diamam_1_imperfect == 5] 
  agedet_0_1 <- data_det$agedet_1_imperfect[data_det$diamam_1_imperfect == 3| data_det$diamam_1_imperfect == 2]
  
  
  # Calculate descriptive statistics for age and detection mode
  agesymp01 <- mean(agesymp_0_1)
  agedet01 <- mean(agedet_0_1)
  agesymp_median01 <- median(agesymp_0_1)
  agedet_median01 <- median(agedet_0_1)
  agesymp_25_01 <- quantile(agesymp_0_1, 0.25)
  agedet_25_01 <- quantile(agedet_0_1, 0.25)
  agesymp_75_01 <- quantile(agesymp_0_1, 0.75)
  agedet_75_01 <- quantile(agedet_0_1, 0.75)
  
  ##
  porp_sympsize1_01 = sum(data_symp$sizesymp[data_symp$diamam_1_imperfect==1 | data_symp$diamam_1_imperfect== 2| data_symp$diamam_1_imperfect==3|
                                               data_symp$diamam_1_imperfect==4| data_symp$diamam_1_imperfect==5] < 10, na.rm = TRUE) 
  porp_sympsize2_01  = sum(data_symp$sizesymp[data_symp$diamam_1_imperfect==1 | data_symp$diamam_1_imperfect== 2| data_symp$diamam_1_imperfect==3|
                                                    data_symp$diamam_1_imperfect==4| data_symp$diamam_1_imperfect==5] >= 10 
                           & data_symp$sizesymp[data_symp$diamam_1_imperfect==1 | data_symp$diamam_1_imperfect== 2| data_symp$diamam_1_imperfect==3|
                                                  data_symp$diamam_1_imperfect==4| data_symp$diamam_1_imperfect==5]<= 20, na.rm = TRUE)
  porp_sympsize3_01  = sum(data_symp$sizesymp[data_symp$diamam_1_imperfect==1 | data_symp$diamam_1_imperfect== 2| data_symp$diamam_1_imperfect==3|
                                                data_symp$diamam_1_imperfect==4| data_symp$diamam_1_imperfect==5] > 20 
                           & data_symp$sizesymp[data_symp$diamam_1_imperfect==1 | data_symp$diamam_1_imperfect== 2| data_symp$diamam_1_imperfect==3|
                                                  data_symp$diamam_1_imperfect==4| data_symp$diamam_1_imperfect==5] <= 50, na.rm = TRUE)
  porp_sympsize4_01  = sum(data_symp$sizesymp[data_symp$diamam_1_imperfect==1 | data_symp$diamam_1_imperfect== 2| data_symp$diamam_1_imperfect==3|
                                                data_symp$diamam_1_imperfect==4| data_symp$diamam_1_imperfect==5] > 50, na.rm = TRUE)
  
  porp_detsize1_01 = sum(data_det$sizedet_1_imperfect[data_det$diamam_1_imperfect == 3 |data_det$diamam_1_imperfect == 2] < 10, na.rm = TRUE) 
  porp_detsize2_01  = sum(data_det$sizedet_1_imperfect[data_det$diamam_1_imperfect == 3 | data_det$diamam_1_imperfect == 2] >= 10 
                          & data_det$sizedet_1_imperfect[data_det$diamam_1_imperfect == 3 | data_det$diamam_1_imperfect == 2] <= 20, na.rm = TRUE)
  porp_detsize3_01  = sum(data_det$sizedet_1_imperfect[data_det$diamam_1_imperfect == 3 | data_det$diamam_1_imperfect == 2] > 20 
                          & data_det$sizedet_1_imperfect[data_det$diamam_1_imperfect == 3 | data_det$diamam_1_imperfect == 2] <= 50, na.rm = TRUE)
  porp_detsize4_01  = sum(data_det$sizedet_1_imperfect[data_det$diamam_1_imperfect == 3 | data_det$diamam_1_imperfect == 2] > 50, na.rm = TRUE)
  
  
  results_df <- rbind(results_df, 
                      data.frame(Summary = rep(c("Number Diagnosed", "Mean Age", 
                                                   "Median Age", "1st Quantile Age",
                                                   "3rd Quantile Age",
                                                   "Tumour size 0-9 mm",
                                                   "Tumour size 10-19 mm",
                                                   "Tumour size 20-50 mm",
                                                   "Tumour size > 50 mm"), each = 1),
                                 No_screen = c(
                                               freq_method2_p0,
                                               agesymp01,
                                               agesymp_median01,
                                               agesymp_25_01,
                                               agesymp_75_01,
                                               porp_sympsize1_01,
                                               porp_sympsize2_01,
                                               porp_sympsize3_01,
                                               porp_sympsize4_01
                                               ),
                                 screen = c(
                                            freq_method2_p00,
                                            agedet01,
                                            agedet_median01,
                                            agedet_25_01,
                                            agedet_75_01,
                                            porp_detsize1_01,
                                            porp_detsize2_01,
                                            porp_detsize3_01,
                                            porp_detsize4_01
                                            ),                                            
                                 stringsAsFactors = FALSE))
                      
                      
  results_list[[file]] <- results_df
}
print(results_df)
# calculate the overall frequency across all simulations
#create a new column ID
#i <- rep(seq_len(nrow(results_df)/1), each = 1)
#overall_freq <- results_df %>%
#  group_by( Attendance, Method) 

#out1 <- tibble::tibble(i,overall_freq)
#out1$p <-out1$prop_screen_detected*100
#Print results
#print(out1)

mean_data <- aggregate(cbind(No_screen, screen) ~ Summary, data = results_df, FUN = mean)
print(mean_data)




#Tumour size distribution

#Set work directory to the folder where your data is saved
setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Optimal")
setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Personalized_mod")



# List all the files in the folder
files <- list.files()
# Ensure 'files' contains at least three files
if (length(files) >= 10) {
  # Subset 'files' to contain only the first three files
  files_subset <- files[1:10]
# Initialize an empty data frame to store results
results_df_symp <- data.frame(
                          onset_symp = numeric(),
                          grr_symp = numeric(),
                          size_symp = numeric(),
                          age_symp = numeric(),
                          BMI_symp = numeric(),
                          stringsAsFactors =FALSE)
results_df_scr <- data.frame(
                          onset_scr = numeric(),
                          grr_scr = numeric(),
                          size_scr = numeric(),
                          age_scr = numeric(),
                          BMI_scr = numeric(),
                          stringsAsFactors =FALSE)
data_det <- list()
data_symp <- list()
results_list <- list()
# Loop through each file
for (file in files_subset) {
  # Read the data
  data2 <- haven::read_sav(file)
  
  # Filter the data, vary for tumour <120mm and between 2mm-50mm
  data_det <- subset(data2, (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65 & sizedet_1_imperfect <= 120))
  data_symp <- subset(data2, (agesymp >= 30 & agesymp <= 65) & (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65) & (sizedet_1_imperfect <= 120))
  
  
  # Process the data and calculate 
onset_symp<- data_symp$atumon [data_symp$sizedet_1_imperfect & data_symp$diamam_1_imperfect == 2]
onset_scr<- data_det$atumon [data_det$sizedet_1_imperfect & data_det$diamam_1_imperfect == 3]
grr_symp<-data_symp$grr[data_symp$sizedet_1_imperfect & data_symp$diamam_1_imperfect == 2]
grr_scr<-data_det$grr[data_det$sizedet_1_imperfect & data_det$diamam_1_imperfect == 3]
size_symp <- data_symp$sizedet_1_imperfect[data_symp$diamam_1_imperfect == 2 ]
size_scr <- data_det$sizedet_1_imperfect[data_det$diamam_1_imperfect == 3 ]
age_symp <- data_symp$agedet_1_imperfect[data_symp$diamam_1_imperfect == 2 ]
age_scr <- data_det$agedet_1_imperfect[data_det$diamam_1_imperfect == 3 ]
BMI_symp <- data_symp$BMI[data_symp$diamam_1_imperfect == 2 ]
BMI_scr <- data_det$BMI[data_det$diamam_1_imperfect == 3 ]
results_df_symp <- rbind(results_df_symp, data.frame(
                                           onset_symp = onset_symp,
                                           grr_symp = grr_symp,
                                           size_symp = size_symp,
                                           age_symp = age_symp,
                                           BMI_symp = age_symp,
                                           stringsAsFactors =FALSE))
results_df_scr <- rbind(results_df_scr, data.frame(
                                          onset_scr = onset_scr,
                                          grr_scr = grr_scr,
                                          size_scr = size_scr,
                                          age_scr = age_scr,
                                          BMI_scr = age_scr,
                                          stringsAsFactors =FALSE))

results_list[[file]] <- results_df_symp
results_list[[file]] <- results_df_scr
}
} else {
  cat("There are not enough files in the 'files' vector.\n")
}
print(results_df_symp)
print(results_df_scr)
data2 <- c(results_df_symp, results_df_scr)
###


# graphical presentation of age at detection distributions
library(ggplot2)
library(dplyr)

#combine data into data frame

min_length <- min(length(onset_symp), length(onset_scr))
data = data.frame(onset_age=c(onset_symp[1:min_length],onset_scr[1:min_length]),
                  group = rep(c("Interval cancer", "Screen detected cancer"), each =min_length))


library(plyr)
mu <- ddply(data, "group", summarise, grp.mean=mean(onset_age))

# Create a density plot with confidence intervals
ggplot(data, aes(x=onset_age,color = group)) + 
  geom_density(alpha = 0.5, size = 1, adjust = 5) +
  geom_vline(data=mu, aes(xintercept=grp.mean, color=group),
             linetype="dashed")+
  labs(#title = "Age at onset distribution", 
       x="Age at onset (years)",
       fill = "Distribution",
       color = "Distribution") +
  theme_minimal() +
  #theme(legend.position="none") + # Remove legend
  xlim(c(0,100)) + 
  #theme(plot.title = element_text(hjust = 0.5))
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "white"),
    plot.title = element_text(hjust = 0.5)
  )




# graphical presentation of tumour size distributions
  
library(ggplot2)
#combine data into data frame
min_length <- min(length(size_symp), length(size_scr))
data = data.frame(tumour_size=c(size_symp[1:min_length],size_scr[1:min_length]),
                  group = rep(c("Interval cancer", "Screen detected cancer"), each =min_length))

library(plyr)
p <- ddply(data, "group", summarise, grp.mean=mean(tumour_size))
# Create a density plot with confidence intervals
ggplot(data, aes(x=tumour_size, color = group)) + 
  geom_density(alpha = 0.5, linewidth = 1, adjust = 5) +
  geom_vline(data=p, aes(xintercept=grp.mean, color=group),
             linetype="dashed")+
  labs(#title = "Tumour Size distribution", 
       x="Tumour Size (mm)",
       fill = "Distribution",
       color = "Detection mode") +
  theme_minimal() +
  xlim(c(0,130)) + 
  #theme(plot.title = element_text(hjust = 0.5))
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "white"),
    plot.title = element_text(hjust = 0.5)
  )


#inverse growth rate
##Scr
set.seed(323)
n = 1000000
mean_grr_scr <- mean(data2$grr_scr)
std_grr_scr<- sd(data2$grr_scr)
grr_sim_scr <- abs(rnorm(n=n, mean = mean_grr_scr, sd = std_grr_scr))

doubling_time_scr <- 365 * log(2)*grr_sim_scr
summary(doubling_time_scr)
sd(doubling_time_scr)

##symp(interval case)
set.seed(323)
n = 1000000
mean_grr_symp <- mean(data2$grr_symp)
std_grr_symp<- sd(data2$grr_symp)
grr_sim_symp <- abs(rnorm(n=n, mean = mean_grr_symp, sd = std_grr_symp))

doubling_time_symp <- 365 * log(2)*grr_sim_symp
summary(doubling_time_symp)
sd(doubling_time_symp)

#Tumour Doubling time

library(ggplot2)
#combine data into data frame
min_length <- min(length(doubling_time_symp), length(doubling_time_scr))
data = data.frame(Doubling=c(doubling_time_symp[1:min_length],doubling_time_scr[1:min_length]),
                  group = rep(c("Interval cancer", "Screen detected cancer"), each =min_length))

library(plyr)
q <- ddply(data, "group", summarise, grp.mean=mean(Doubling))
# Create a density plot with confidence intervals
ggplot(data, aes(x=Doubling, color = group)) + 
  geom_density(alpha = 0.5, size = 0.5, adjust = 5) +
  geom_vline(data=q, aes(xintercept=grp.mean, color=group),
             linetype="dashed")+
  labs( 
    x="Tumour volume doubling time (days) ",
    fill = "Distribution",
    color = "Distribution") +
  theme_minimal() +
  #xlim(c(0,5)) + 
  scale_x_continuous(breaks = seq(0, 1000, by = 200)) +
  #theme(plot.title = element_text(hjust = 0.5))
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "white"),
    plot.title = element_text(hjust = 0.5)
  )


# tumour presence time
Scr_age_det_presence <- data2$age_scr-data2$onset_scr
summary(Scr_age_det_presence)
sd(Scr_age_det_presence)
symp_presence <- data2$age_symp - data2$onset_symp
summary(symp_presence)
sd(symp_presence)


library(ggplot2)
#combine data into data frame
min_length <- min(length(symp_presence), length(Scr_age_det_presence))
data = data.frame(tumour_size=symp_presence[1:min_length],
                  group = rep("Interval cancer", each =min_length))
  
# Create a violin plot
ggplot(data, aes(x = group, y = tumour_size, fill = group)) +
  geom_violin(trim = FALSE, alpha = 0.5) +
  geom_boxplot(width = 0.1, fill = "white", color = "black", alpha = 0.7) +  # Overlay box plot for better representation of quartiles
  labs(x = "Group", y = "Tumour presence time (years)", fill = "Distribution") +
  theme_minimal() +
  theme(legend.position="none") + # Remove legend
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_rect(fill = "white"),
    plot.title = element_text(hjust = 0.5)
  )





#Set work directory to the folder where your data is saved
#setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Personalized_c")
setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Personalized_mod")
# List all the files in the folder
files <- list.files()
# Ensure 'files' contains at least three files
if (length(files) >= 10) {
  # Subset 'files' to contain only the first three files
  files_subset <- files[1:10]
  # Initialize an empty data frame to store results
  results_df_scr <- data.frame(
    onset_scr = numeric(),
    grr_scr = numeric(),
    size_scr = numeric(),
    age_scr = numeric(),
    stringsAsFactors =FALSE)
  results_df_int <- data.frame(
    onset_int = numeric(),
    grr_int = numeric(),
    size_int = numeric(),
    age_int = numeric(),
    stringsAsFactors =FALSE)
  
  
  data_det <- list()
  data_symp <- list()
  results_list <- list()
  # Loop through each file
  for (file in files_subset) {
    # Read the data
    data2 <- haven::read_sav(file)
    
    
    # Filter the data for tumour size between 2-50mm
    data_det <- subset(data2, (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65) & (sizedet_1_imperfect >=2 & sizedet_1_imperfect <=50))
    data_symp <- subset(data2, (agesymp >= 30 & agesymp <= 65) & (sizesymp >= 2 & sizesymp <= 50) & (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65))
    
    # Process the data and calculate 
    onset_int <- data_symp$atumon [data_symp$BMI < 18.5 & data_symp$diamam_1_imperfect == 2]
    onset_scr <- data_det$atumon [data_det$BMI < 18.5 & data_det$diamam_1_imperfect == 3]
    grr_int <- data_symp$grr[data_symp$BMI < 18.5 & data_symp$diamam_1_imperfect == 2]
    grr_scr <- data_det$grr[data_det$BMI < 18.5 & data_det$diamam_1_imperfect == 3]
    size_int <- data_symp$sizedet_1_imperfect[data_symp$BMI < 18.5 & data_symp$diamam_1_imperfect == 2 ]
    size_scr <- data_det$sizedet_1_imperfect[data_det$BMI < 18.5 & data_det$diamam_1_imperfect == 3 ]
    age_int <- data_symp$agedet_1_imperfect[data_symp$BMI < 18.5 & data_symp$diamam_1_imperfect == 2 ]
    age_scr <- data_det$agedet_1_imperfect[data_det$BMI < 18.5& data_det$diamam_1_imperfect == 3 ]
    
    results_df_scr <- rbind(results_df_scr, data.frame(
      onset_scr = onset_scr,
      grr_scr = grr_scr,
      size_scr = size_scr,
      age_scr = age_scr,
      stringsAsFactors =FALSE))
    results_df_int <- rbind(results_df_int, data.frame(
      onset_int = onset_int,
      grr_int = grr_int,
      size_int = size_int,
      age_int = age_int,
      stringsAsFactors =FALSE))
    
    results_list[[file]] <- results_df_int
    results_list[[file]] <- results_df_scr
  }
} else {
  cat("There are not enough files in the 'files' vector.\n")
}
print(results_df_scr)
print(results_df_int)
data2<- c(results_df_int, results_df_scr)
#inverse growth rate
##scr
set.seed(323)
n = 1000000
mean_grr_scr <- mean(data2$grr_scr)
std_grr_scr<- sd(data2$grr_scr)
grr_sim_scr <- abs(rnorm(n=n, mean = mean_grr_scr, sd = std_grr_scr))

doubling_time_scr <- 365 * log(2)*grr_sim_scr
median(doubling_time_scr)
summary(doubling_time_scr)
sd(doubling_time_scr)

#symp interval

set.seed(323)
n = 1000000
mean_grr_int <- mean(data2$grr_int)
std_grr_int <- sd(data2$grr_int)
grr_sim_int <- abs(rnorm(n=n, mean = mean_grr_int, sd = std_grr_int))

doubling_time_int <- 365 * log(2)*grr_sim_int
median(doubling_time_int)
summary(doubling_time_int)
sd(doubling_time_int)

#BMI 18.5-29.9

setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Personalized_mod")
# List all the files in the folder
files <- list.files()
# Ensure 'files' contains at least three files
if (length(files) >= 10) {
  # Subset 'files' to contain only the first three files
  files_subset <- files[1:10]
  # Initialize an empty data frame to store results
  results_df_scr <- data.frame(
    onset_scr = numeric(),
    grr_scr = numeric(),
    size_scr = numeric(),
    age_scr = numeric(),
    stringsAsFactors =FALSE)
  results_df_int <- data.frame(
    onset_int = numeric(),
    grr_int = numeric(),
    size_int = numeric(),
    age_int = numeric(),
    stringsAsFactors =FALSE)
  
  
  data_det <- list()
  data_symp <- list()
  results_list <- list()
  # Loop through each file
  for (file in files_subset) {
    # Read the data
    data2 <- haven::read_sav(file)
    
    
    data_det <- subset(data2, (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65) & (sizedet_1_imperfect >=2 & sizedet_1_imperfect <=50))
    data_symp <- subset(data2, (agesymp >= 30 & agesymp <= 65) & (sizesymp >= 2 & sizesymp <= 50) & (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65))
    
    
    # Process the data and calculate 
    onset_int <- data_symp$atumon [(data_symp$BMI >= 18.5 & data_symp$BMI < 25 ) & data_symp$diamam_1_imperfect == 2]
    onset_scr <- data_det$atumon [(data_det$BMI >= 18.5 & data_det$BMI < 25 ) & data_det$diamam_1_imperfect == 3]
    grr_int <- data_symp$grr[(data_symp$BMI >= 18.5 & data_symp$BMI < 25 ) & data_symp$diamam_1_imperfect == 2]
    grr_scr <- data_det$grr[(data_det$BMI >= 18.5 & data_det$BMI < 25 ) & data_det$diamam_1_imperfect == 3]
    size_int <- data_symp$sizedet_1_imperfect[(data_symp$BMI >= 18.5 & data_symp$BMI < 25)  & data_symp$diamam_1_imperfect == 2 ]
    size_scr <- data_det$sizedet_1_imperfect[(data_det$BMI >= 18.5 & data_det$BMI < 25 ) & data_det$diamam_1_imperfect == 3 ]
    age_int <- data_symp$agedet_1_imperfect[(data_symp$BMI >= 18.5 & data_symp$BMI < 25)  & data_symp$diamam_1_imperfect == 2 ]
    age_scr <- data_det$agedet_1_imperfect[(data_det$BMI >= 18.5 & data_det$BMI < 25) & data_det$diamam_1_imperfect == 3 ]
    
    results_df_scr <- rbind(results_df_scr, data.frame(
      onset_scr = onset_scr,
      grr_scr = grr_scr,
      size_scr = size_scr,
      age_scr = age_scr,
      stringsAsFactors =FALSE))
    results_df_int <- rbind(results_df_int, data.frame(
      onset_int = onset_int,
      grr_int = grr_int,
      size_int = size_int,
      age_int = age_int,
      stringsAsFactors =FALSE))
    
    results_list[[file]] <- results_df_int
    results_list[[file]] <- results_df_scr
  }
} else {
  cat("There are not enough files in the 'files' vector.\n")
}
print(results_df_scr)
print(results_df_int)
data2<- c(results_df_int, results_df_scr)
#inverse growth rate
##scr
set.seed(323)
n = 1000000
mean_grr_scr <- mean(data2$grr_scr)
std_grr_scr<- sd(data2$grr_scr)
grr_sim_scr <- abs(rnorm(n=n, mean = mean_grr_scr, sd = std_grr_scr))

doubling_time_scr <- 365 * log(2)*grr_sim_scr
median(doubling_time_scr)
summary(doubling_time_scr)
sd(doubling_time_scr)

#symp interval

set.seed(323)
n = 1000000
mean_grr_int <- mean(data2$grr_int)
std_grr_int <- sd(data2$grr_int)
grr_sim_int <- abs(rnorm(n=n, mean = mean_grr_int, sd = std_grr_int))

doubling_time_int <- 365 * log(2)*grr_sim_int
median(doubling_time_int)
summary(doubling_time_int)
sd(doubling_time_int)



#BMI 25-29.9

setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Personalized_mod")
# List all the files in the folder
files <- list.files()
# Ensure 'files' contains at least three files
if (length(files) >= 10) {
  # Subset 'files' to contain only the first three files
  files_subset <- files[1:10]
  # Initialize an empty data frame to store results
  results_df_scr <- data.frame(
    onset_scr = numeric(),
    grr_scr = numeric(),
    size_scr = numeric(),
    age_scr = numeric(),
    stringsAsFactors =FALSE)
  results_df_int <- data.frame(
    onset_int = numeric(),
    grr_int = numeric(),
    size_int = numeric(),
    age_int = numeric(),
    stringsAsFactors =FALSE)
  
  
  data_det <- list()
  data_symp <- list()
  results_list <- list()
  # Loop through each file
  for (file in files_subset) {
    # Read the data
    data2 <- haven::read_sav(file)
    
    
    # Filter the data
    data_det <- subset(data2, (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65) & (sizedet_1_imperfect >=2 & sizedet_1_imperfect <=50))
    data_symp <- subset(data2, (agesymp >= 30 & agesymp <= 65) & (sizesymp >= 2 & sizesymp <= 50) & (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65))
    
    
    # Process the data and calculate 
    onset_int <- data_symp$atumon [(data_symp$BMI >= 25 & data_symp$BMI < 30 ) & data_symp$diamam_1_imperfect == 2]
    onset_scr <- data_det$atumon [(data_det$BMI >= 25 & data_det$BMI < 30 ) & data_det$diamam_1_imperfect == 3]
    grr_int <- data_symp$grr[(data_symp$BMI >= 25 & data_symp$BMI < 30 ) & data_symp$diamam_1_imperfect == 2]
    grr_scr <- data_det$grr[(data_det$BMI >= 25 & data_det$BMI < 30 ) & data_det$diamam_1_imperfect == 3]
    size_int <- data_symp$sizedet_1_imperfect[(data_symp$BMI >= 25 & data_symp$BMI < 30)  & data_symp$diamam_1_imperfect == 2 ]
    size_scr <- data_det$sizedet_1_imperfect[(data_det$BMI >= 25 & data_det$BMI < 30 ) & data_det$diamam_1_imperfect == 3 ]
    age_int <- data_symp$agedet_1_imperfect[(data_symp$BMI >= 25 & data_symp$BMI < 30)  & data_symp$diamam_1_imperfect == 2 ]
    age_scr <- data_det$agedet_1_imperfect[(data_det$BMI >= 25 & data_det$BMI < 30) & data_det$diamam_1_imperfect == 3 ]
    
    results_df_scr <- rbind(results_df_scr, data.frame(
      onset_scr = onset_scr,
      grr_scr = grr_scr,
      size_scr = size_scr,
      age_scr = age_scr,
      stringsAsFactors =FALSE))
    results_df_int <- rbind(results_df_int, data.frame(
      onset_int = onset_int,
      grr_int = grr_int,
      size_int = size_int,
      age_int = age_int,
      stringsAsFactors =FALSE))
    
    results_list[[file]] <- results_df_int
    results_list[[file]] <- results_df_scr
  }
} else {
  cat("There are not enough files in the 'files' vector.\n")
}
print(results_df_scr)
print(results_df_int)
data2<- c(results_df_int, results_df_scr)
#inverse growth rate
##scr
set.seed(323)
n = 1000000
mean_grr_scr <- mean(data2$grr_scr)
std_grr_scr<- sd(data2$grr_scr)
grr_sim_scr <- abs(rnorm(n=n, mean = mean_grr_scr, sd = std_grr_scr))

doubling_time_scr <- 365 * log(2)*grr_sim_scr
median(doubling_time_scr)
summary(doubling_time_scr)
sd(doubling_time_scr)

#symp interval

set.seed(323)
n = 1000000
mean_grr_int <- mean(data2$grr_int)
std_grr_int <- sd(data2$grr_int)
grr_sim_int <- abs(rnorm(n=n, mean = mean_grr_int, sd = std_grr_int))

doubling_time_int <- 365 * log(2)*grr_sim_int
median(doubling_time_int)
summary(doubling_time_int)
sd(doubling_time_int)


### BMI 30+

setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Personalized_mod")
# List all the files in the folder
files <- list.files()
# Ensure 'files' contains at least three files
if (length(files) >= 10) {
  # Subset 'files' to contain only the first three files
  files_subset <- files[1:10]
  # Initialize an empty data frame to store results
  results_df_scr <- data.frame(
    onset_scr = numeric(),
    grr_scr = numeric(),
    size_scr = numeric(),
    age_scr = numeric(),
    stringsAsFactors =FALSE)
  results_df_int <- data.frame(
    onset_int = numeric(),
    grr_int = numeric(),
    size_int = numeric(),
    age_int = numeric(),
    stringsAsFactors =FALSE)
  
  
  data_det <- list()
  data_symp <- list()
  results_list <- list()
  # Loop through each file
  for (file in files_subset) {
    # Read the data
    data2 <- haven::read_sav(file)
    
    
    # Filter the data
    data_det <- subset(data2, (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65) & (sizedet_1_imperfect >=2 & sizedet_1_imperfect <=50))
    data_symp <- subset(data2, (agesymp >= 30 & agesymp <= 65) & (sizesymp >= 2 & sizesymp <= 50) & (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65))
    
    # Process the data and calculate 
    onset_int <- data_symp$atumon [data_symp$BMI >= 30 & data_symp$diamam_1_imperfect == 2]
    onset_scr <- data_det$atumon [data_det$BMI >= 30 & data_det$diamam_1_imperfect == 3]
    grr_int <- data_symp$grr[data_symp$BMI >= 30 & data_symp$diamam_1_imperfect == 2]
    grr_scr <- data_det$grr[data_det$BMI >= 30 & data_det$diamam_1_imperfect == 3]
    size_int <- data_symp$sizedet_1_imperfect[data_symp$BMI >= 30 & data_symp$diamam_1_imperfect == 2 ]
    size_scr <- data_det$sizedet_1_imperfect[data_det$BMI >= 30 & data_det$diamam_1_imperfect == 3 ]
    age_int <- data_symp$agedet_1_imperfect[data_symp$BMI >= 30& data_symp$diamam_1_imperfect == 2 ]
    age_scr <- data_det$agedet_1_imperfect[data_det$BMI >= 30 & data_det$diamam_1_imperfect == 3 ]
    
    results_df_scr <- rbind(results_df_scr, data.frame(
      onset_scr = onset_scr,
      grr_scr = grr_scr,
      size_scr = size_scr,
      age_scr = age_scr,
      stringsAsFactors =FALSE))
    results_df_int <- rbind(results_df_int, data.frame(
      onset_int = onset_int,
      grr_int = grr_int,
      size_int = size_int,
      age_int = age_int,
      stringsAsFactors =FALSE))
    
    results_list[[file]] <- results_df_int
    results_list[[file]] <- results_df_scr
  }
} else {
  cat("There are not enough files in the 'files' vector.\n")
}
print(results_df_scr)
print(results_df_int)
data2<- c(results_df_int, results_df_scr)
#inverse growth rate
##scr
set.seed(323)
n = 1000000
mean_grr_scr <- mean(data2$grr_scr)
std_grr_scr<- sd(data2$grr_scr)
grr_sim_scr <- abs(rnorm(n=n, mean = mean_grr_scr, sd = std_grr_scr))

doubling_time_scr <- 365 * log(2)*grr_sim_scr
median(doubling_time_scr)
summary(doubling_time_scr)
sd(doubling_time_scr)

#symp interval

set.seed(323)
n = 1000000
mean_grr_int <- mean(data2$grr_int)
std_grr_int <- sd(data2$grr_int)
grr_sim_int <- abs(rnorm(n=n, mean = mean_grr_int, sd = std_grr_int))

doubling_time_int <- 365 * log(2)*grr_sim_int
summary(doubling_time_int)
sd(doubling_time_int)






############ CPH Analysis
#Set work directory to the folder where your data is saved
setwd("C:/Users/Asamoah/OneDrive/Desktop/Sch/Second year/Thesis/Final_code/Personalized_mod")

####
files <- list.files()

# Create an empty data frame to store the results
results_df <- data.frame(grr = numeric(),
                         age_onset = numeric(),
                         age_det = numeric(),
                         size_det = numeric(),
                         det_inter_status = numeric(),
                         BMI = numeric(),
                         stringsAsFactors =FALSE)
dataHR <- list()
results_list <-list()
# loop through each file in the folder
for (file in files) {
  #read the data
  data2 <- haven::read_sav(file)
    
    # Filter the data
    dataHR <- subset(data2, (agesymp >= 30 & agesymp <= 65) & (sizesymp >= 2 & sizesymp <= 50) & (agedet_1_imperfect >= 30 & agedet_1_imperfect <= 65))
    
    ##
    #calculate the frequency of symp and screen detection
    grr <- dataHR$grr[dataHR$diamam_1_imperfect == 2 | dataHR$diamam_1_imperfect == 3]
    age_onset <- dataHR$atumon[dataHR$diamam_1_imperfect == 2 | dataHR$diamam_1_imperfect == 3]
    age_det <- dataHR$agedet_1_imperfect[dataHR$diamam_1_imperfect == 2 | dataHR$diamam_1_imperfect == 3]
    size_det <- dataHR$sizedet_1_imperfect[dataHR$diamam_1_imperfect == 2 | dataHR$diamam_1_imperfect == 3]
    det_inter_status <- dataHR$diamam_1_imperfect[dataHR$diamam_1_imperfect == 2 | dataHR$diamam_1_imperfect == 3]
    BMI <- dataHR$BMI[dataHR$diamam_1_imperfect == 2 | dataHR$diamam_1_imperfect == 3]
    
    # append the frequency values to the results data frame
    results_df <- rbind(results_df, 
                        data.frame(grr = grr,
                                   age_onset = age_onset,
                                   age_det = age_det,
                                   size_det = size_det,
                                   det_inter_status = det_inter_status,
                                   BMI = BMI,
                                   stringsAsFactors =FALSE))
        results_list[[file]] <- results_df
}


  #print(results_df)
  #nrow(results_df)
  #summary(results_df$BMI)
  # Create BMI categories
  results_df$BMI_Category <- cut(results_df$BMI, 
                                 breaks = c(0, 18.5, 25, 29.9, Inf) ,
                                 labels = c("BMI < 18.5", "BMI: 18.5 - 24.9", "BMI: 25 - 29.9", "BMI >= 30")
                                 )
  
 #set the event you want: interval-detected =2 and screen-detected =3
  results_df$status <- as.numeric(results_df$det_inter_status==2)
  
  #calculate number of cases
  table_cases <- table(results_df$status, results_df$BMI_Category)
  print(table_cases )
  

  library(survival)
  set.seed(246)
  # Fit Cox proportional hazards model with BMI category as a stratifying variable
  cox_model <- coxph(Surv(age_onset, status) ~ BMI_Category, data = results_df)
  
  # Summarize the model
  summary(cox_model)
  
  event_fit_bmi <- survfit(cox_model)
                              
  library(survival)
  library(ranger)
  library(ggplot2)
  library(dplyr)
  library(ggfortify)

  # Plot separate Kaplan-Meier curves for each BMI category
  plot(event_fit_bmi, 
       #main = "Time to interval cancers curves by BMI Category", 
       xlab = "Time (years)", ylab = "Event Probability", col = c("blue", "red", "green", "black"), lty = 1, xlim = c(10, 65))
  
  # Add a legend with better positioning
  legend("topright", legend = levels(results_df$BMI_Category), col = c("blue", "red", "green", "black"), lty = 1, cex = 0.8,  x.intersp = 0.75, y.intersp = 0.75)
  
  
 